package utils;

import java.sql.Connection;

import sun.jvm.hotspot.runtime.StaticBaseConstructor;

public class BBDD {
	public static void main(String[] args) {
		
		public static void conectar() {
			
			return Connection;
		}
	}
}
