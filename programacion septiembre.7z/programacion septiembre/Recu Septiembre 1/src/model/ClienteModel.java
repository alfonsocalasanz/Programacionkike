package model;

public class ClienteModel implements  {

}
