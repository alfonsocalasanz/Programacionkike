package model;

public class Cliente {
	  private int id ;
	    private String Nombre;
	    private String Apellido;
	    private String Sexo;
	    private int FechaNacimiento;
}
